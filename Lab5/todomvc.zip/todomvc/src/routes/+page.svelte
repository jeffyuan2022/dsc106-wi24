<script>
    import App from '../components/App.svelte';
</script>

<App />

